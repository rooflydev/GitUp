import GitUpDashboard from '../gitup-dashboard';

export default function Home() {
  return <GitUpDashboard />;
}
